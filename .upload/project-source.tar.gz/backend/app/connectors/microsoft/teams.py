class TeamsConnector:
    pass
