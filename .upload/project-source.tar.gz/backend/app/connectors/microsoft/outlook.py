class OutlookConnector:
    pass
